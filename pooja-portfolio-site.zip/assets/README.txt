Add your photo as 'profile.jpg' in this folder to display it in the site.
